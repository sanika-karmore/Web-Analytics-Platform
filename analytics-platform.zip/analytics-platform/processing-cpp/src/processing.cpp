#include "processing.h"

namespace analytics {

std::vector<ColumnSummary> CsvProcessor::summarize(const std::vector<std::string>& header,
                                                   const std::vector<std::vector<std::string>>& rows) const {
    std::vector<ColumnSummary> summaries;
    summaries.reserve(header.size());

    for (const auto& name : header) {
        summaries.push_back(ColumnSummary{name, 0});
    }

    for (const auto& row : rows) {
        for (std::size_t i = 0; i < summaries.size() && i < row.size(); ++i) {
            if (!row[i].empty()) {
                summaries[i].non_null_count++;
            }
        }
    }

    return summaries;
}

} // namespace analytics
