#include "processing.h"

#include <iostream>

int main() {
    analytics::CsvProcessor processor;
    std::vector<std::string> header = {"region", "amount"};
    std::vector<std::vector<std::string>> rows = {
        {"east", "10"},
        {"", "5"},
        {"west", ""}
    };

    auto summaries = processor.summarize(header, rows);
    for (const auto& summary : summaries) {
        std::cout << summary.name << ": " << summary.non_null_count << "\n";
    }

    return 0;
}
