# C++ Processing Module (Stub)

This is a lightweight C++17 processing module stub intended for optional future integration.

## Build (local)

```powershell
cmake -S . -B build
cmake --build build
```

## Run demo

```powershell
.\build\analytics_processing_demo.exe
```

## Notes

- The demo counts non-null values per column.
- Future: expose this as a shared library and call from Java via JNI or a small gRPC sidecar.
