#pragma once

#include <string>
#include <vector>

namespace analytics {

struct ColumnSummary {
    std::string name;
    std::size_t non_null_count;
};

class CsvProcessor {
public:
    CsvProcessor() = default;

    std::vector<ColumnSummary> summarize(const std::vector<std::string>& header,
                                         const std::vector<std::vector<std::string>>& rows) const;
};

} // namespace analytics
