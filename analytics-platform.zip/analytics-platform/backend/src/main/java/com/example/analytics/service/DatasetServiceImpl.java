package com.example.analytics.service;

import com.example.analytics.api.QueryRequest;
import com.example.analytics.api.QueryResponse;
import com.example.analytics.api.UploadResponse;
import com.example.analytics.model.Dataset;
import com.example.analytics.model.DatasetColumn;
import com.example.analytics.model.DatasetStatus;
import com.example.analytics.processing.QuerySqlBuilder;
import com.example.analytics.repository.DatasetRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.transaction.annotation.Transactional;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class DatasetServiceImpl implements DatasetService {
    private static final Logger logger = LoggerFactory.getLogger(DatasetServiceImpl.class);

    private final DatasetRepository datasetRepository;
    private final JdbcTemplate jdbcTemplate;
    private final QuerySqlBuilder querySqlBuilder = new QuerySqlBuilder();

    public DatasetServiceImpl(DatasetRepository datasetRepository, JdbcTemplate jdbcTemplate) {
        this.datasetRepository = datasetRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    @Transactional
    public UploadResponse upload(MultipartFile file) {
        String originalFilename = file.getOriginalFilename();
        String datasetName = (originalFilename == null || originalFilename.isBlank())
                ? "dataset"
                : originalFilename;

        Dataset dataset = new Dataset(datasetName, originalFilename, DatasetStatus.QUEUED);

        String message = "Upload accepted. Processing will start shortly.";
        try {
            char delimiter = inferColumnsFromHeader(file, dataset);
            dataset.setStatus(DatasetStatus.PROCESSING);
            Dataset saved = datasetRepository.save(dataset);

            createDataTable(saved);
            long rowCount = loadRows(file, saved, delimiter);

            saved.setStatus(DatasetStatus.READY);
            datasetRepository.save(saved);
            message = "Upload completed. Loaded " + rowCount + " rows.";
            return new UploadResponse(saved.getId().toString(), saved.getStatus().name(), message);
        } catch (IOException e) {
            dataset.setStatus(DatasetStatus.FAILED);
            message = "Upload failed while reading file header.";
        } catch (Exception e) {
            dataset.setStatus(DatasetStatus.FAILED);
            message = "Upload failed while loading data.";
            logger.error("Upload failed", e);
        }

        Dataset saved = datasetRepository.save(dataset);
        return new UploadResponse(saved.getId().toString(), saved.getStatus().name(), message);
    }

    @Override
    public QueryResponse query(QueryRequest request) {
        long start = System.currentTimeMillis();
        java.util.UUID datasetId;
        try {
            datasetId = java.util.UUID.fromString(request.datasetId());
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Invalid datasetId format.");
        }
        Dataset dataset = datasetRepository.findById(datasetId)
                .orElseThrow(() -> new IllegalArgumentException("Dataset not found"));
        if (dataset.getStatus() != DatasetStatus.READY) {
            throw new IllegalStateException("Dataset is not ready for querying");
        }

        QuerySqlBuilder.QueryPlan plan = querySqlBuilder.build(dataset, request);
        logger.info("Generated query plan. sql={}, paramsCount={}", plan.sql(), plan.params().size());

        List<Map<String, Object>> rows;
        if (plan.params().isEmpty()) {
            rows = jdbcTemplate.queryForList(plan.sql());
        } else {
            rows = jdbcTemplate.queryForList(plan.sql(), plan.params().toArray());
        }

        long elapsed = System.currentTimeMillis() - start;
        return new QueryResponse(rows, rows.size(), elapsed);
    }

    private char inferColumnsFromHeader(MultipartFile file, Dataset dataset) throws IOException {
        String headerLine;
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {
            headerLine = reader.readLine();
        }

        if (headerLine == null || headerLine.isBlank()) {
            dataset.setStatus(DatasetStatus.FAILED);
            throw new IOException("Empty header");
        }

        char delimiter = detectDelimiter(headerLine);

        try (Reader reader = new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8);
             CSVParser parser = CSVFormat.DEFAULT.builder()
                     .setDelimiter(delimiter)
                     .setTrim(true)
                     .setHeader()
                     .setSkipHeaderRecord(true)
                     .build()
                     .parse(reader)) {
            Map<String, Integer> headerMap = parser.getHeaderMap();
            if (headerMap == null || headerMap.isEmpty()) {
                dataset.setStatus(DatasetStatus.FAILED);
                throw new IOException("Missing header");
            }

            List<String> headerNames = headerMap.entrySet().stream()
                    .sorted(Comparator.comparingInt(Map.Entry::getValue))
                    .map(Map.Entry::getKey)
                    .toList();

            List<String[]> sampleRows = readSampleRows(parser, headerNames.size(), 50);

            for (int i = 0; i < headerNames.size(); i++) {
                String rawName = headerNames.get(i) == null ? "" : headerNames.get(i).trim();
                String name = rawName.isEmpty() ? "column_" + (i + 1) : rawName;
                ColumnInference inference = inferColumn(i, sampleRows);
                DatasetColumn column = new DatasetColumn(name, inference.dataType, inference.nullable, i + 1);
                dataset.addColumn(column);
            }
        }

        return delimiter;
    }

    private char detectDelimiter(String headerLine) {
        int commas = countChar(headerLine, ',');
        int tabs = countChar(headerLine, '\t');
        int semicolons = countChar(headerLine, ';');
        if (tabs >= commas && tabs >= semicolons) {
            return '\t';
        }
        if (semicolons >= commas) {
            return ';';
        }
        return ',';
    }

    private int countChar(String line, char target) {
        int count = 0;
        for (int i = 0; i < line.length(); i++) {
            if (line.charAt(i) == target) {
                count++;
            }
        }
        return count;
    }

    private List<String[]> readSampleRows(CSVParser parser, int columnCount, int maxRows) throws IOException {
        List<String[]> rows = new ArrayList<>();
        for (CSVRecord record : parser) {
            if (rows.size() >= maxRows) {
                break;
            }
            if (record.size() == 0) {
                continue;
            }
            String[] row = new String[columnCount];
            for (int i = 0; i < columnCount; i++) {
                row[i] = i < record.size() ? record.get(i) : "";
            }
            rows.add(row);
        }
        return rows;
    }

    private ColumnInference inferColumn(int index, List<String[]> rows) {
        boolean nullable = false;
        ColumnType current = ColumnType.INTEGER;

        for (String[] row : rows) {
            if (index >= row.length) {
                nullable = true;
                continue;
            }
            String value = row[index].trim();
            if (value.isEmpty()) {
                nullable = true;
                continue;
            }
            ColumnType detected = detectType(value);
            current = promote(current, detected);
            if (current == ColumnType.STRING) {
                break;
            }
        }

        return new ColumnInference(current.toStorageType(), nullable);
    }

    private ColumnType detectType(String value) {
        if (isInteger(value)) {
            return ColumnType.INTEGER;
        }
        if (isDecimal(value)) {
            return ColumnType.DECIMAL;
        }
        if (isBoolean(value)) {
            return ColumnType.BOOLEAN;
        }
        if (isIsoDate(value)) {
            return ColumnType.DATE;
        }
        if (isIsoDateTime(value)) {
            return ColumnType.TIMESTAMP;
        }
        return ColumnType.STRING;
    }

    private ColumnType promote(ColumnType current, ColumnType detected) {
        if (current == detected) {
            return current;
        }
        if (current == ColumnType.INTEGER && detected == ColumnType.DECIMAL) {
            return ColumnType.DECIMAL;
        }
        if ((current == ColumnType.INTEGER || current == ColumnType.DECIMAL) && detected == ColumnType.STRING) {
            return ColumnType.STRING;
        }
        if (detected == ColumnType.STRING) {
            return ColumnType.STRING;
        }
        if ((current == ColumnType.DATE && detected == ColumnType.TIMESTAMP)
                || (current == ColumnType.TIMESTAMP && detected == ColumnType.DATE)) {
            return ColumnType.TIMESTAMP;
        }
        return ColumnType.STRING;
    }

    private boolean isInteger(String value) {
        int start = value.startsWith("-") ? 1 : 0;
        if (start == value.length()) {
            return false;
        }
        for (int i = start; i < value.length(); i++) {
            if (!Character.isDigit(value.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private boolean isDecimal(String value) {
        try {
            Double.parseDouble(value);
            return value.contains(".");
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    private boolean isBoolean(String value) {
        String normalized = value.toLowerCase(Locale.ROOT);
        return normalized.equals("true") || normalized.equals("false") || normalized.equals("0") || normalized.equals("1");
    }

    private boolean isIsoDate(String value) {
        if (value.length() != 10) {
            return false;
        }
        return value.charAt(4) == '-' && value.charAt(7) == '-';
    }

    private boolean isIsoDateTime(String value) {
        return value.contains("T") && value.length() >= 16;
    }

    private enum ColumnType {
        INTEGER,
        DECIMAL,
        BOOLEAN,
        DATE,
        TIMESTAMP,
        STRING;

        String toStorageType() {
            return switch (this) {
                case INTEGER -> "INTEGER";
                case DECIMAL -> "DECIMAL";
                case BOOLEAN -> "BOOLEAN";
                case DATE -> "DATE";
                case TIMESTAMP -> "TIMESTAMP";
                case STRING -> "STRING";
            };
        }
    }

    private record ColumnInference(String dataType, boolean nullable) {
    }

    private void createDataTable(Dataset dataset) {
        List<DatasetColumn> columns = sortedColumns(dataset);
        String columnDefs = columns.stream()
                .map(c -> escapeIdentifier(c.getName()) + " " + toSqlType(c.getDataType()))
                .collect(Collectors.joining(", "));
        String sql = "CREATE TABLE IF NOT EXISTS " + datasetTableName(dataset.getId())
                + " (" + columnDefs + ")";
        jdbcTemplate.execute(sql);
    }

    private long loadRows(MultipartFile file, Dataset dataset, char delimiter) throws IOException {
        List<DatasetColumn> columns = sortedColumns(dataset);
        String columnList = columns.stream()
                .map(c -> escapeIdentifier(c.getName()))
                .collect(Collectors.joining(", "));
        String placeholders = columns.stream().map(c -> "?").collect(Collectors.joining(", "));

        String sql = "INSERT INTO " + datasetTableName(dataset.getId())
                + " (" + columnList + ") VALUES (" + placeholders + ")";

        List<Object[]> batch = new ArrayList<>();
        long rowCount = 0;

        try (Reader reader = new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8);
             CSVParser parser = CSVFormat.DEFAULT.builder()
                     .setDelimiter(delimiter)
                     .setTrim(true)
                     .setHeader()
                     .setSkipHeaderRecord(true)
                     .build()
                     .parse(reader)) {
            for (CSVRecord record : parser) {
                Object[] values = new Object[columns.size()];
                for (int i = 0; i < columns.size(); i++) {
                    String raw = i < record.size() ? record.get(i) : "";
                    values[i] = parseValue(raw, columns.get(i).getDataType());
                }
                batch.add(values);
                rowCount++;
                if (batch.size() >= 500) {
                    jdbcTemplate.batchUpdate(sql, batch);
                    batch.clear();
                }
            }
        }

        if (!batch.isEmpty()) {
            jdbcTemplate.batchUpdate(sql, batch);
        }

        return rowCount;
    }

    private Object parseValue(String raw, String dataType) {
        if (raw == null) {
            return null;
        }
        String value = raw.trim();
        if (value.isEmpty()) {
            return null;
        }
        return switch (dataType) {
            case "INTEGER" -> Long.parseLong(value);
            case "DECIMAL" -> new java.math.BigDecimal(value);
            case "BOOLEAN" -> parseBoolean(value);
            case "DATE" -> java.time.LocalDate.parse(value);
            case "TIMESTAMP" -> java.time.OffsetDateTime.parse(value);
            default -> value;
        };
    }

    private boolean parseBoolean(String value) {
        String normalized = value.toLowerCase(Locale.ROOT);
        return normalized.equals("true") || normalized.equals("1");
    }

    private List<DatasetColumn> sortedColumns(Dataset dataset) {
        return dataset.getColumns().stream()
                .sorted(Comparator.comparingInt(DatasetColumn::getOrdinalPosition))
                .toList();
    }

    private String toSqlType(String dataType) {
        return switch (dataType) {
            case "INTEGER" -> "BIGINT";
            case "DECIMAL" -> "NUMERIC";
            case "BOOLEAN" -> "BOOLEAN";
            case "DATE" -> "DATE";
            case "TIMESTAMP" -> "TIMESTAMPTZ";
            default -> "TEXT";
        };
    }

    private String escapeIdentifier(String value) {
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    private String datasetTableName(UUID datasetId) {
        return "dataset_" + datasetId.toString().replace("-", "");
    }
}
