package com.example.analytics.service;

import com.example.analytics.api.QueryRequest;
import com.example.analytics.api.QueryResponse;
import com.example.analytics.api.UploadResponse;
import org.springframework.web.multipart.MultipartFile;

public interface DatasetService {
    UploadResponse upload(MultipartFile file);

    QueryResponse query(QueryRequest request);
}
