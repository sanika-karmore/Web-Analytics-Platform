package com.example.analytics.processing;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Configuration
public class ProcessingExecutorConfig {
    @Bean(destroyMethod = "shutdown")
    public ExecutorService processingExecutor() {
        return Executors.newFixedThreadPool(4);
    }
}
