package com.example.analytics.processing;

import com.example.analytics.api.QueryRequest;
import com.example.analytics.model.Dataset;
import com.example.analytics.model.DatasetColumn;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

public class QuerySqlBuilder {

    public QueryPlan build(Dataset dataset, QueryRequest request) {
        Map<String, DatasetColumn> columns = dataset.getColumns().stream()
                .collect(Collectors.toMap(DatasetColumn::getName, c -> c));

        String tableName = datasetTableName(dataset.getId());

        String selectClause = buildSelect(columns, request);
        String whereClause = buildWhere(columns, request.filters());
        String groupByClause = buildGroupBy(columns, request.groupBy());

        List<Object> params = new ArrayList<>();
        if (request.filters() != null) {
            for (Map.Entry<String, Object> entry : request.filters().entrySet()) {
                String column = entry.getKey();
                if (columns.containsKey(column)) {
                    params.add(entry.getValue());
                }
            }
        }

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ").append(selectClause)
                .append(" FROM ").append(tableName);
        if (!whereClause.isBlank()) {
            sql.append(" WHERE ").append(whereClause);
        }
        if (!groupByClause.isBlank()) {
            sql.append(" GROUP BY ").append(groupByClause);
        }

        return new QueryPlan(sql.toString(), params);
    }

    private String buildSelect(Map<String, DatasetColumn> columns, QueryRequest request) {
        List<String> parts = new ArrayList<>();

        if (request.groupBy() != null && !request.groupBy().isBlank()) {
            ensureColumnExists(columns, request.groupBy());
            parts.add(escapeIdentifier(request.groupBy()));
        }

        if (request.aggregations() != null && !request.aggregations().isEmpty()) {
            Set<String> aliases = new HashSet<>();
            for (QueryRequest.AggregationSpec spec : request.aggregations()) {
                String op = normalizeOp(spec.op());
                String column = spec.column();
                String expression;
                if (op.equals("COUNT") && (column == null || column.equals("*"))) {
                    expression = "COUNT(*)";
                } else {
                    ensureColumnExists(columns, column);
                    expression = op + "(" + escapeIdentifier(column) + ")";
                }
                String alias = makeAlias(op, column, aliases);
                parts.add(expression + " AS " + escapeIdentifier(alias));
            }
        }

        if (parts.isEmpty()) {
            parts.add("*");
        }

        return String.join(", ", parts);
    }

    private String buildWhere(Map<String, DatasetColumn> columns, Map<String, Object> filters) {
        if (filters == null || filters.isEmpty()) {
            return "";
        }
        List<String> clauses = new ArrayList<>();
        for (String key : filters.keySet()) {
            if (!columns.containsKey(key)) {
                continue;
            }
            clauses.add(escapeIdentifier(key) + " = ?");
        }
        return String.join(" AND ", clauses);
    }

    private String buildGroupBy(Map<String, DatasetColumn> columns, String groupBy) {
        if (groupBy == null || groupBy.isBlank()) {
            return "";
        }
        ensureColumnExists(columns, groupBy);
        return escapeIdentifier(groupBy);
    }

    private void ensureColumnExists(Map<String, DatasetColumn> columns, String column) {
        if (column == null || column.isBlank() || !columns.containsKey(column)) {
            throw new IllegalArgumentException("Unknown column: " + column);
        }
    }

    private String normalizeOp(String op) {
        if (op == null) {
            throw new IllegalArgumentException("Aggregation op is required.");
        }
        String normalized = op.toUpperCase(Locale.ROOT).trim();
        return switch (normalized) {
            case "SUM", "AVG", "COUNT", "MIN", "MAX" -> normalized;
            default -> throw new IllegalArgumentException("Unsupported aggregation op: " + op);
        };
    }

    private String makeAlias(String op, String column, Set<String> used) {
        String base = op.toLowerCase(Locale.ROOT) + "_" + (column == null ? "all" : column);
        String alias = base;
        int index = 1;
        while (!used.add(alias)) {
            alias = base + "_" + index;
            index++;
        }
        return alias;
    }

    private String escapeIdentifier(String value) {
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    private String datasetTableName(UUID datasetId) {
        return "dataset_" + datasetId.toString().replace("-", "");
    }

    public record QueryPlan(String sql, List<Object> params) {
    }
}
