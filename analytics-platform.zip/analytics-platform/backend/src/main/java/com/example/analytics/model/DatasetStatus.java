package com.example.analytics.model;

public enum DatasetStatus {
    QUEUED,
    PROCESSING,
    READY,
    FAILED
}
