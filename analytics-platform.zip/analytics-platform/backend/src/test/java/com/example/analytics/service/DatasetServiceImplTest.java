package com.example.analytics.service;

import com.example.analytics.model.Dataset;
import com.example.analytics.model.DatasetColumn;
import com.example.analytics.model.DatasetStatus;
import com.example.analytics.repository.DatasetRepository;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockMultipartFile;

import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class DatasetServiceImplTest {

    @Test
    void upload_infersColumnTypesAndNullability_fromCsv() {
        DatasetRepository repository = mock(DatasetRepository.class);
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        when(repository.save(any(Dataset.class))).thenAnswer(invocation -> {
            Dataset dataset = invocation.getArgument(0);
            ensureId(dataset);
            return dataset;
        });

        DatasetServiceImpl service = new DatasetServiceImpl(repository, jdbcTemplate);

        String csv = "id,price,active,created_on,created_at,notes\n"
                + "1,10.5,true,2024-01-01,2024-01-01T12:30:00,hello\n"
                + "2,,false,2024-02-01,2024-02-01T09:15:00,\"with, comma\"\n";

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "sample.csv",
                "text/csv",
                csv.getBytes(StandardCharsets.UTF_8)
        );

        service.upload(file);

        ArgumentCaptor<Dataset> captor = ArgumentCaptor.forClass(Dataset.class);
        verify(repository, atLeastOnce()).save(captor.capture());
        Dataset dataset = captor.getAllValues().get(captor.getAllValues().size() - 1);

        assertEquals(DatasetStatus.READY, dataset.getStatus());
        assertEquals(6, dataset.getColumns().size());

        Map<String, DatasetColumn> byName = dataset.getColumns().stream()
                .collect(Collectors.toMap(DatasetColumn::getName, c -> c));

        assertType(byName, "id", "INTEGER", false);
        assertType(byName, "price", "DECIMAL", true);
        assertType(byName, "active", "BOOLEAN", false);
        assertType(byName, "created_on", "DATE", false);
        assertType(byName, "created_at", "TIMESTAMP", false);
        assertType(byName, "notes", "STRING", true);
    }

    @Test
    void upload_supportsSemicolonDelimiter() {
        DatasetRepository repository = mock(DatasetRepository.class);
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        when(repository.save(any(Dataset.class))).thenAnswer(invocation -> {
            Dataset dataset = invocation.getArgument(0);
            ensureId(dataset);
            return dataset;
        });

        DatasetServiceImpl service = new DatasetServiceImpl(repository, jdbcTemplate);

        String csv = "name;score\nAlice;10\nBob;11\n";

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "scores.csv",
                "text/csv",
                csv.getBytes(StandardCharsets.UTF_8)
        );

        service.upload(file);

        ArgumentCaptor<Dataset> captor = ArgumentCaptor.forClass(Dataset.class);
        verify(repository, atLeastOnce()).save(captor.capture());
        Dataset dataset = captor.getAllValues().get(captor.getAllValues().size() - 1);

        List<DatasetColumn> columns = dataset.getColumns();
        assertEquals(2, columns.size());
        assertEquals("name", columns.get(0).getName());
        assertEquals("score", columns.get(1).getName());
    }

    private void assertType(Map<String, DatasetColumn> byName, String name, String dataType, boolean nullable) {
        DatasetColumn column = byName.get(name);
        assertNotNull(column, "Missing column: " + name);
        assertEquals(dataType, column.getDataType(), "Type mismatch for " + name);
        assertEquals(nullable, column.isNullable(), "Nullability mismatch for " + name);
    }

    private void ensureId(Dataset dataset) {
        try {
            java.lang.reflect.Field field = Dataset.class.getDeclaredField("id");
            field.setAccessible(true);
            if (field.get(dataset) == null) {
                field.set(dataset, UUID.randomUUID());
            }
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
}
