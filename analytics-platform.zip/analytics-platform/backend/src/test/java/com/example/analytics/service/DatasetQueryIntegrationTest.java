package com.example.analytics.service;

import com.example.analytics.api.QueryRequest;
import com.example.analytics.api.QueryResponse;
import com.example.analytics.api.UploadResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.mock.web.MockMultipartFile;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@ActiveProfiles("test")
class DatasetQueryIntegrationTest {

    @Autowired
    private DatasetService datasetService;

    @Test
    void uploadAndQuery_returnsAggregatedResults() {
        String csv = "region,amount\n"
                + "east,10\n"
                + "west,5\n"
                + "east,7\n";

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "sample.csv",
                "text/csv",
                csv.getBytes(StandardCharsets.UTF_8)
        );

        UploadResponse upload = datasetService.upload(file);

        QueryRequest.AggregationSpec agg = new QueryRequest.AggregationSpec("amount", "SUM");
        QueryRequest request = new QueryRequest(upload.datasetId(),
                null,
                "region",
                List.of(agg));

        QueryResponse response = datasetService.query(request);

        assertTrue(response.rowCount() > 0);
        Map<String, Object> firstRow = response.rows().get(0);
        assertTrue(firstRow.containsKey("region"));
        assertTrue(firstRow.keySet().stream().anyMatch(k -> k.toLowerCase().contains("sum")));
    }

    @Test
    void query_withFilter_returnsFilteredRows() {
        String csv = "region,amount\n"
                + "east,10\n"
                + "west,5\n";

        MockMultipartFile file = new MockMultipartFile(
                "file",
                "sample.csv",
                "text/csv",
                csv.getBytes(StandardCharsets.UTF_8)
        );

        UploadResponse upload = datasetService.upload(file);

        QueryRequest request = new QueryRequest(upload.datasetId(),
                Map.of("region", "east"),
                null,
                null);

        QueryResponse response = datasetService.query(request);

        assertEquals(1, response.rowCount());
        assertEquals("east", response.rows().get(0).get("region"));
    }
}
